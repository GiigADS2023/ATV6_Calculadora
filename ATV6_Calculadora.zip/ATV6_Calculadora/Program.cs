﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Switch2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite o primeiro número:");
            float n1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo número:");
            float n2 = float.Parse(Console.ReadLine());
            Console.WriteLine("Escolha a opção algoritma que deseja fazer:");
            Console.WriteLine("1 - Adição\r\n2 - Subtração\r\n3 - Divisão\r\n4 - Multiplicação"); // \r\n  pular linha

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    float adicao = n1 + n2;
                    Console.WriteLine("Resposta: " + adicao);
                    break;

                case "2":
                    float subtracao = n1 - n2;
                    Console.WriteLine("Resposta: " + subtracao);
                    break;

                case "3":
                    float divisao = n1 / n2;
                    Console.WriteLine("Resposta: " + divisao);
                    break;

                case "4":
                    float multiplicacao = n1 * n2;
                    Console.WriteLine("Resposta: " + multiplicacao);
                    break;

                default:
                    Console.WriteLine("Não há essa opção :(");
                    break;
            }

            Console.ReadLine();
        }
    }
}
